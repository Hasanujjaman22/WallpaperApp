<?php

$con  = mysqli_connect("localhost", "u142119685_hasandb", "Hasan@2001#");

mysqli_select_db($con, "u142119685_imgdata");

echo "connected";


$category = $_POST["category"];
$img = $_POST["upload"];
$image_name = $_FILES['upload']['tmp_name'];




$filename = "IMG".rand().".jpg";

//$filename = uniqid() . "." . $ext;
file_put_contents("images/". $filename,base64_decode($img));
echo "running";

$qry = "INSERT INTO tbl_staff (`id`, `category`, `image`) VALUES (NULL, '$category','$filename')";

$res = mysqli_query($con, $qry);

if($res == true){
    echo "file uploaded successfully";
}else{
    echo "could not upload file";
}



?>