
<?php



$conn = mysqli_connect("localhost", "u142119685_hasandb", "Hasan@2001#", "u142119685_imgdata");

echo "connected";


   
   
   
   if (isset($_POST['submit'])) {

    // Get the form data
    $category = $_POST['category'];
    $image_name = $_FILES['image']['name'];
    $image_size = $_FILES['image']['size'];
    $image_tmp = $_FILES['image']['tmp_name'];

    // Get the image extension
    $ext = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));

    // Validate the image format
    if (($ext == "jpg") || ($ext == "png") || ($ext == "jpeg") || ($ext == "gif")) {

        // Generate a unique image name
        $image_name = uniqid() . "." . $ext;

        // Upload the image to the server
        move_uploaded_file($image_tmp, "images/" . $image_name);

        // Insert the record into the database
        $sql = "INSERT INTO tbl_staff (category, image) VALUES ('$category', '$image_name')";
        if (mysqli_query($conn, $sql)) {
            echo "Image uploaded successfully.";
            
        } else {
            echo "Error: " . mysqli_error($conn);
        }
     } else {
        echo "Invalid image format.";
    }
}



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories</title>


    <link rel="stylesheet" href="categories.css">

    
  <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>




<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
  integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">



<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.16.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</head>
<body>

<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a href="#" class="navbar-brand">Wallpaper App Admin</a>



      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true"
          aria-expanded="false">
          Hasanujjamanmd2001@gmail.com
        </button>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="#">Log Out</a>

        </div>
      </div>

    </div>

  </nav>


  <div class="row h-100 bg-light">

    <div class="col-lg-2 bg-secondary">

      <ul class="nav flex-column">
        <li class="nav-item">
          <a href="images.php" class="nav-link">
            <span class="text-dark">Images</span>
          </a>
        </li>
        <li class="nav-item">
          <a href="Categories.php" class="nav-link" >
            <span class="text-dark">Categories</span>
          </a>
        </li>
      </ul>

    </div>


    <div class="col-lg-10">
      <div class="container" id="container">
      <form action="Categories.php" method="post" enctype="multipart/form-data">
  <label for="category">Select Category:</label>
  <select name="category">
    <option value="cat1">Category 1</option>
    <option value="cat2">Category 2</option>
    <option value="cat3">Category 3</option>
    <option value="cat4">Category 4</option>
    <option value="cat5">Category 5</option>
  </select>
  <br>
  <label for="image">Select Image File:</label>
  <input type="file" name="image" required>
  <input type="submit" name="submit" value="Upload">
</form>
      </div>
    </div>

  </div>







</body>
</html>