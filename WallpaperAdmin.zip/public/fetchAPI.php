<?php

$conn  = mysqli_connect("localhost", "u142119685_hasandb", "Hasan@2001#", "u142119685_imgdata");

$category = $_POST["category"];

// if($category == "cat1"){


$qry = "select * from tbl_staff";
$raw = mysqli_query($conn, $qry);

while($res = mysqli_fetch_array($raw)){
    $data[]  = $res;
}

print(json_encode($data));
// }elseif($category == "cat2"){
    
// $qry = "select * from tbl_staff WHERE category = 'cat2'";
// $raw = mysqli_query($conn, $qry);

// while($res = mysqli_fetch_array($raw)){
//     $data[]  = $res;
// }

// print(json_encode($data));
// } if($category == "cat3"){
    
// $qry = "select * from tbl_staff WHERE category = 'cat3'";
// $raw = mysqli_query($conn, $qry);

// while($res = mysqli_fetch_array($raw)){
//     $data[]  = $res;
// }

// print(json_encode($data));
// }

?>