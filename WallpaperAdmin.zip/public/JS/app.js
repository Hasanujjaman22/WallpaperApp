

  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-app.js";
  
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-analytics.js";
  import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-auth.js";

  import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-auth.js";


  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyAQTWYi2U_qNVlLvEnxZQZPkyCg35URm6g",
    authDomain: "mywallpaperapp-10880.firebaseapp.com",
    projectId: "mywallpaperapp-10880",
    storageBucket: "mywallpaperapp-10880.appspot.com",
    messagingSenderId: "425256832087",
    appId: "1:425256832087:web:416e9954d748ba8b542712",
    measurementId: "G-4HBXQ2P8BX"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
  const auth = getAuth(app);



//inputs


  const login = document.getElementById('btn-login');

  login.addEventListener("click", function(event){

    event.preventDefault();

    const  email = document.getElementById('email').value;
    const password = document.getElementById('password').value; 

    signInWithEmailAndPassword(auth, email, password)
  .then((userCredential) => {
    // Signed in 
    // const user = userCredential.user;


    console.log(userCredential);
    window.location.href="admin.html";
    
    
    // ...
  })
  .catch((error) => {
    const errorCode = error.code;
    const errorMessage = error.message;

    alert(errorCode);
    alert(errorMessage);
  });

})



onAuthStateChanged(auth, (user) => {
    if (user) {
        window.location.href ="admin.html";
      
      const uid = user.uid;
      // window.location.href ="index.html";
      // ...
    } else {
      
      // User is signed out
      // ...
    }
  });



