// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-app.js";
  
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-analytics.js";

import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-auth.js";


// import { getStorage, ref, uploadBytesResumable, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-storage.js";

// import { getDatabase, ref, set } from "firebase/database";



// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional



const firebaseConfig = {
  apiKey: "AIzaSyAQTWYi2U_qNVlLvEnxZQZPkyCg35URm6g",
  authDomain: "mywallpaperapp-10880.firebaseapp.com",
  projectId: "mywallpaperapp-10880",
  storageBucket: "mywallpaperapp-10880.appspot.com",
  messagingSenderId: "425256832087",
  appId: "1:425256832087:web:416e9954d748ba8b542712",
  measurementId: "G-4HBXQ2P8BX"
};






// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);
  





onAuthStateChanged(auth, (user) => {
  if (user) {

    const uid = user.uid;
    // window.location.href ="index.html";
    // ...
  } else {
    window.location.href ="index.html";
    
    // User is signed out
    // ...
  }
});


