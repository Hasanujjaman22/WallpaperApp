
<?php
$conn = mysqli_connect("localhost", "u142119685_hasandb", "Hasan@2001#", "u142119685_imgdata");



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories</title>


    <link rel="stylesheet" href="categories.css">

    
  <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>




<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
  integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">



<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.16.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</head>
<body>

<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a href="#" class="navbar-brand">Wallpaper App Admin</a>



      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true"
          aria-expanded="false">
          Hasanujjamanmd2001@gmail.com
        </button>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="#">Log Out</a>

        </div>
      </div>

    </div>

  </nav>


  <div class="row h-100 bg-light">

    <div class="col-lg-2 bg-secondary">

      <ul class="nav flex-column">
        <li class="nav-item">
          <a href="images.php" class="nav-link">
            <span class="text-dark">Images</span>
          </a>
        </li>
        <li class="nav-item">
          <a href="Categories.php" class="nav-link" >
            <span class="text-dark">Categories</span>
          </a>
        </li>
      </ul>

    </div>


    <span class="col-lg-10 ">
      <span class="container" id="container">

      <h1>hello</h1>

     <?php  
     
     $sql1 = "SELECT * FROM tbl_staff where category = 'cat1' ";
     $sql2 = "SELECT * FROM tbl_staff where category = 'cat2' ";
     $sql3 = "SELECT * FROM tbl_staff where category = 'cat3' ";
     $sql4 = "SELECT * FROM tbl_staff where category = 'cat4' ";
     $sql5 = "SELECT * FROM tbl_staff where category = 'cat5' ";


greet($conn, $sql1);
greet($conn, $sql2);
greet($conn, $sql3);
greet($conn, $sql4);
greet($conn, $sql5);




function greet($conn, $sql) {
  $result = mysqli_query($conn, $sql);

// Display the images on the website
if (mysqli_num_rows($result) > 0) {
    
    $row = mysqli_fetch_assoc($result);
    
     echo '<h3>' . $row["category"] . '</h3>';
     
    while($row) {
       
        echo  '<span> <img width = 200ps src="images/' . $row["image"] . '" alt="' . $row["category"] . '"> </span>';
        
        $row = mysqli_fetch_assoc($result);
    }
} else {
    echo "No images found.";
}
}
     
     ?>
     
      </span>
    </span>

  </div>







</body>
</html>